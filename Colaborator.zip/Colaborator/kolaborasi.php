<?php
include "conn.php";

$query = "SELECT id, sender, project_name, name, created_at FROM files";
$sql = mysqli_query($conn, $query);
$no = 0;
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Workspace | ColabPluss</title>
    <link rel="icon" href="icon10.png">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/style4.css">
    <script src="jquery-3.1.1.js"></script>	
    <script src="js/home.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

        body, html {
            height: 100%;
        }
        .sb-nav-fixed {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .d-flex {
            flex-grow: 1;
            display: flex;
        }
        .logo-img {
            width: 40px; /* Sesuaikan dengan ukuran logo */
            height: auto; /* Biarkan aspek rasio tetap */
            margin-right: 5px; /* Jarak antara logo dan teks */
            margin-left: 15px;
        }
        .sidebar-nav {
            flex: 0 0 250px; /* or any desired width */
            display: flex;
            flex-direction: column;
            height: 100%;
            background: linear-gradient(to right, #fc8d00, #fbb901);
        }
        .container-fluid {
            flex: 1;
            padding: 0;
        }
        .gradient-text {
            background: linear-gradient(to right, #fc8d00, #fbb901);
            -webkit-background-clip: text;
            color: transparent;
        }
        .button {
            background: linear-gradient(to right, #fc8d00, #fbb901);
            font-weight: bold;
        }
        .sidebar-nav .nav-item2 .nav-link {
            color: black;
        }
        .sidebar-nav .nav-item2 .nav-link i {
            color: black;
        }
        [data-bs-theme="light"] .sidebar-nav .nav-item2 .nav-link,
        [data-bs-theme="light"] .sidebar-nav .nav-item2 .nav-link i {
            color: white; /* Light mode color */
        }
        .item-bg {
            background: linear-gradient(to right, #fc8d00, #fbb901);
        }
        .item_content .card-item {
            color: black;
        }
        .item_content .card-item i {
            color: black;
        }
        [data-bs-theme="light"] .item_content .card-item,
        [data-bs-theme="light"] .item_content .card-item i {
            color: white; /* Light mode color */
        }
    </style>
</head>
<body class="sb-nav-fixed">
<nav class="sb-topnav navbar navbar-expand" style="background-color: var(--bs-body-bg);">
    <div class="d-flex align-items-center">
            <img src="icon10.png" alt="CollabPluss Logo" class="logo-img">
            <a class="navbar-brand ps-3" href="dashboard.php"><b>ColabPluss</b></a>
        </div>
        <div class="ms-auto me-0 me-md-3 my-2 my-md-0">
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                        <button class="btn nav-link dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-moon-stars-fill theme-icon-active" data-theme-icon-active="bi bi-moon-stars-fill"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button" data-bs-theme-value="dark">
                                    <i class="bi bi-moon-stars-fill me-2" data-theme-icon="bi bi-moon-stars-fill"></i>
                                    Dark Mode
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button" data-bs-theme-value="light">
                                    <i class="bi bi-brightness-high-fill me-2" data-theme-icon="bi bi-brightness-high-fill"></i>
                                    Light Mode
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button" data-bs-theme-value="auto">
                                    <i class="bi bi-circle-half me-2" data-theme-icon="bi bi-circle-half"></i>
                                    Auto Mode
                                </button>
                            </li>
                        </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirm Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to logout?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a href="logout.php" class="btn btn-primary">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex">
        <div class="text-white p-3 sidebar-nav">
            <ul class="nav flex-column">
                <li class="nav-item2">
                    <a class="nav-link active" href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
                </li>
                <li class="nav-item2">
                    <a class="nav-link dropdown-toggle" href="#" id="masterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-box me-2"></i> Kolaborasi
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="masterDropdown">
                        <li><a class="dropdown-item" href="kolaborasi.php"><i class="fas fa-solid fa-briefcase me-2"></i> Workspace</a></li>
                        <li><a class="dropdown-item" href="room_chat.php"><i class="bi bi-chat-dots-fill me-2"></i> Room Chat</a></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center p-3 shadow-sm">
                <h4 class="mb-0"><b>WORKSPACE</b></h4>
            </div>
            <div class="card mt-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <label for="entries" class="form-label">Tampilkan</label>
                            <select class="form-select d-inline-block w-auto" id="entries">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                            <span>data</span>
                        </div>
                        <div>
                            <input type="text" class="form-control" placeholder="Cari" id="search">
                        </div>
                    </div>

                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Sender Name</th>
                                <th>Project Name</th>
                                <th>File Name</th>
                                <th>Day & Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            while ($result = mysqli_fetch_assoc($sql)) {
                                echo '<tr>';
                                echo '<td><center>' . ++$no . '.</center></td>';
                                echo '<td>' . $result['sender'] . '</td>';
                                echo '<td>' . $result['project_name'] . '</td>';
                                echo '<td>' . $result['name'] . '</td>';
                                echo '<td>' . $result['created_at'] . '</td>';
                                echo '<td><a href="download.php?id=' . $result['id'] . '" class="btn button">Download</a></td>';
                                echo '</tr>';
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    /*!
    * Color mode toggler for Bootstrap's docs (https://getbootstrap.com/)
    * Copyright 2011-2024 The Bootstrap Authors
    * Licensed under the Creative Commons Attribution 3.0 Unported License.
    */

    (() => {
        'use strict';

            const storedTheme = localStorage.getItem('theme');
            const selectedTheme = storedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            const rootElement = document.documentElement;
            const themeIconActive = document.querySelector('.theme-icon-active');
            const themeBtns = document.querySelectorAll('[data-bs-theme-value]');
            const themeIcons = {
                'dark': 'bi-moon-stars-fill',
                'light': 'bi-brightness-high-fill',
                'auto': 'bi-circle-half'
            };

            const setTheme = (theme) => {
                rootElement.setAttribute('data-bs-theme', theme);
                localStorage.setItem('theme', theme);

                themeBtns.forEach(btn => {
                    const icon = btn.querySelector('i[data-theme-icon]');
                    if (icon) {
                        icon.classList.remove('active-icon');
                    }
                    if (btn.getAttribute('data-bs-theme-value') === theme) {
                        icon.classList.add('active-icon');
                    }
                });

                themeIconActive.className = `bi ${themeIcons[theme]} theme-icon-active`;
            };

            setTheme(selectedTheme);

            themeBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    const theme = btn.getAttribute('data-bs-theme-value');
                    setTheme(theme);
                });
            });
    })()
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"></script>

</body>
</html>
