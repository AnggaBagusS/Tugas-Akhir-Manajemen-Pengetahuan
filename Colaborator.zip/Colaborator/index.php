<?php
	session_start();
	if (isset($_SESSION['message'])){
	echo $_SESSION['message'];
	unset ($_SESSION['message']);
	}
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Public Chat</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

  <link rel="stylesheet" href="css/style4.css">

  <style>
    /* Form Module */
  .form-module {
    position: relative;
    background: #ffffff;
    max-width: 320px;
    width: 100%;
    /* Gradient border-top */
    border-top: 5px solid;
    border-image: linear-gradient(to left, #fc8d00, #fbb901);
    border-image-slice: 1;
    box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
    margin: 0 auto;
  }
  .form-module .toggle {
    cursor: pointer;
    position: absolute;
    top: -0;
    right: -0;
    background: #fc8d00; /* Update color */
    width: 30px;
    height: 30px;
    margin: -5px 0 0;
    color: #ffffff;
    font-size: 12px;
    line-height: 30px;
    text-align: center;
  }
  .form-module button {
    cursor: pointer;
    background: linear-gradient(to left, #fbb901, #fc8d00);
    width: 100%;
    border: 0;
    padding: 10px 15px;
    color: #ffffff;
    transition: 0.3s ease;
  }
  .form-module button:hover {
    background: #fbb901; /* Update color */
  }
  .form-module h2 {
  margin: 0 0 20px;
  color: #fbb901;
  font-size: 18px;
  font-weight: 400;
  line-height: 1;
  }
  .form-module h2.Welcome {
  margin: 0 0 20px;
  color: #fbb901;
  font-size: 18px;
  font-weight: 700; /* Set font-weight to 700 for bold */
  line-height: 1;
  }


  </style>
  
</head>

<body>

  
<!-- Form Mixin-->
<!-- Input Mixin-->
<!-- Button Mixin-->
<!-- Pen Title-->
<div class="pen-title">
  <h1><!-- ChatME--></h1>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div class="toggle"><i class="fa fa-times fa-pencil"></i>
  </div>
  <div class="form">
    <h2 class="Welcome">Welcome!!</h2>
    <h2>Login to your account</h2>
    <form name="form_login" method="post" action="login.php">
      <input type="text" placeholder="Username" name="username" />
      <input type="password" placeholder="Password" name="password" />
      <button>Login</button>
    </form>
  </div>
  <div class="cta"><center>Created by : MapenCuy Team &copy 2024</center></div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>


    <script  src="js/index.js"></script>




</body>

</html>
