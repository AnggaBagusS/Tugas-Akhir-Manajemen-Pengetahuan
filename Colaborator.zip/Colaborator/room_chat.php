<?php
include "conn.php";
session_start();
if (!isset($_SESSION['userid']) ||(trim ($_SESSION['userid']) == '')) {
header('location:index.php');
exit();
}

$uquery=mysqli_query($conn,"SELECT * FROM `user` WHERE userid='".$_SESSION['userid']."'");
$urow=mysqli_fetch_assoc($uquery);
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ColabPluss</title>
    <link rel="icon" href="icon10.png">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/style4.css">
    <script src="jquery-3.1.1.js"></script>	
    <script src="js/home.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $(document).keypress(function(e){ //using keyboard enter key
            displayResult();
            /* Send Message	*/	
            
                if(e.which === 13){ 
                        if($('#msg').val() == ""){
                        alert('Please write message first');
                    }else{
                        $msg = $('#msg').val();
                        $id = $('#id').val();
                        $.ajax({
                            type: "POST",
                            url: "send_message.php",
                            data: {
                                msg: $msg,
                                id: $id,
                            },
                            success: function(){
                                displayResult();
                                $('#msg').val(''); //clears the textarea after submit
                            }
                        });
                    }	

                    /* $("form").submit(); 
                    alert('You press enter key!'); */
                } 
            }
        ); 


        $(document).ready(function(){ //using send button
            displayResult();
            /* Send Message	*/	
                
                $('#send_msg').on('click', function(){
                    if($('#msg').val() == ""){
                        alert('Please write message first');
                    }else{
                        $msg = $('#msg').val();
                        $id = $('#id').val();
                        $.ajax({
                            type: "POST",
                            url: "send_message.php",
                            data: {
                                msg: $msg,
                                id: $id,
                            },
                            success: function(){
                                displayResult();
                                $('#msg').val(''); //clears the textarea after submit
                            }
                        });
                    }	
                });
            /* END */
            });
            
            function displayResult(){
                $id = $('#id').val();
                $.ajax({
                    url: 'send_message.php',
                    type: 'POST',
                    async: false,
                    data:{
                        id: $id,
                        res: 1,
                    },
                    success: function(response){
                        $('#result').html(response);
                    }
                });
            }
    </script>
    <style>
        body, html {
            height: 100%;
        }
        .sb-nav-fixed {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .d-flex {
            flex-grow: 1;
            display: flex;
        }
        .logo-img {
            width: 40px; /* Sesuaikan dengan ukuran logo */
            height: auto; /* Biarkan aspek rasio tetap */
            margin-right: 5px; /* Jarak antara logo dan teks */
            margin-left: 15px;
        }
        .sidebar-nav {
            flex: 0 0 250px; /* or any desired width */
            display: flex;
            flex-direction: column;
            height: 100%;
            background: linear-gradient(to right, #fc8d00, #fbb901);
        }
        .container-fluid {
            flex: 1;
            padding: 0;
        }
        .gradient-text {
            background: linear-gradient(to right, #fc8d00, #fbb901);
            -webkit-background-clip: text;
            color: transparent;
        }
        .sidebar-nav .nav-item2 .nav-link {
            color: black;
        }
        .sidebar-nav .nav-item2 .nav-link i {
            color: black;
        }
        [data-bs-theme="light"] .sidebar-nav .nav-item2 .nav-link,
        [data-bs-theme="light"] .sidebar-nav .nav-item2 .nav-link i {
            color: white; /* Light mode color */
        }
        .item-bg {
            background: linear-gradient(to right, #fc8d00, #fbb901);
        }
        .item_content .card-item {
            color: black;
        }
        .item_content .card-item i {
            color: black;
        }
        [data-bs-theme="light"] .item_content .card-item,
        [data-bs-theme="light"] .item_content .card-item i {
            color: white; /* Light mode color */
        }

        #chat_room th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background: linear-gradient(to right, #fc8d00, #fbb901);
            color: white;
            border-radius: 10px 10px 0 0px;
        }

        .button { /* style for send button */
            background: linear-gradient(to right, #fc8d00, #fbb901);
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            -webkit-transition-duration: 0.4s; /* Safari */
            transition-duration: 0.4s;
            border-radius: 10px;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand" style="background-color: var(--bs-body-bg);">
    <div class="d-flex align-items-center">
            <img src="icon10.png" alt="CollabPluss Logo" class="logo-img">
            <a class="navbar-brand ps-3" href="dashboard.php"><b>ColabPluss</b></a>
        </div>
        <div class="ms-auto me-0 me-md-3 my-2 my-md-0">
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                        <button class="btn nav-link dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-moon-stars-fill theme-icon-active" data-theme-icon-active="bi bi-moon-stars-fill"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button" data-bs-theme-value="dark">
                                    <i class="bi bi-moon-stars-fill me-2" data-theme-icon="bi bi-moon-stars-fill"></i>
                                    Dark Mode
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button" data-bs-theme-value="light">
                                    <i class="bi bi-brightness-high-fill me-2" data-theme-icon="bi bi-brightness-high-fill"></i>
                                    Light Mode
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item d-flex align-items-center" type="button" data-bs-theme-value="auto">
                                    <i class="bi bi-circle-half me-2" data-theme-icon="bi bi-circle-half"></i>
                                    Auto Mode
                                </button>
                            </li>
                        </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirm Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to logout?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a href="logout.php" class="btn btn-primary">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex">
        <div class="text-white p-3 sidebar-nav">
            <ul class="nav flex-column">
                <li class="nav-item2">
                    <a class="nav-link active" href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
                </li>
                <li class="nav-item2">
                    <a class="nav-link dropdown-toggle" href="#" id="masterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-box me-2"></i> Kolaborasi
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="masterDropdown">
                        <li><a class="dropdown-item" href="kolaborasi.php"><i class="fas fa-solid fa-briefcase me-2"></i> Workspace</a></li>
                        <li><a class="dropdown-item" href="room_chat.php"><i class="bi bi-chat-dots-fill me-2"></i> Room Chat</a></li>
                    </ul>
                </li>
            </ul>
        </div>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center p-3">
                <h4 class="mb-0"><b>Room Chat</b></h4>
            </div>
            <table id="chat_room" align="center">
                <tr>
                <th><h4>Hi, <a href="profile.php?userid=<?php echo $_SESSION['userid']; ?>"  style="color: black; font-weight: bold"><?php echo $urow['your_name']; ?></a></h4></th>
                </tr>
                <?php
                    $query=mysqli_query($conn,"select * from `chat_room`");
                    $row=mysqli_fetch_array($query);
                ?>
                            <div>
                            <tr>
                            <td><?php echo $row['chat_room_name']; ?></td><br><br>
                            </tr>
                            </div>
                        <tr>
                            <td>
                            <div id="result" style="overflow-y:scroll; height:300px; width: 605px;"></div>
                            <form class="form">
                                <!--<input type="text" id="msg">--><br/>
                                <textarea id="msg" rows="4" cols="85"></textarea><br/>
                                <input type="hidden" value="<?php echo $row['chat_room_id']; ?>" id="id">
                                <button type="button" id="send_msg" class="button button2" style="color: black; font-weight: bold">Send</button>
                            </form>
                            </td>
                        </tr>

            </table>
        </div>
    </div>

    <script>
    /*!
    * Color mode toggler for Bootstrap's docs (https://getbootstrap.com/)
    * Copyright 2011-2024 The Bootstrap Authors
    * Licensed under the Creative Commons Attribution 3.0 Unported License.
    */

    (() => {
        'use strict';

            const storedTheme = localStorage.getItem('theme');
            const selectedTheme = storedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            const rootElement = document.documentElement;
            const themeIconActive = document.querySelector('.theme-icon-active');
            const themeBtns = document.querySelectorAll('[data-bs-theme-value]');
            const themeIcons = {
                'dark': 'bi-moon-stars-fill',
                'light': 'bi-brightness-high-fill',
                'auto': 'bi-circle-half'
            };

            const setTheme = (theme) => {
                rootElement.setAttribute('data-bs-theme', theme);
                localStorage.setItem('theme', theme);

                themeBtns.forEach(btn => {
                    const icon = btn.querySelector('i[data-theme-icon]');
                    if (icon) {
                        icon.classList.remove('active-icon');
                    }
                    if (btn.getAttribute('data-bs-theme-value') === theme) {
                        icon.classList.add('active-icon');
                    }
                });

                themeIconActive.className = `bi ${themeIcons[theme]} theme-icon-active`;
            };

            setTheme(selectedTheme);

            themeBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    const theme = btn.getAttribute('data-bs-theme-value');
                    setTheme(theme);
                });
            });
    })()
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"></script>

</body>
</html>
