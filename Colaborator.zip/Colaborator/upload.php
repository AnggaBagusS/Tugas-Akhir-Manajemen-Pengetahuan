<?php

if (isset($_POST['submit'])) {
    include "koneksi.php";

    // Check connection
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // File upload path
    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileType = $_FILES['file']['type'];
    $senderName = $_POST['sender_name'];
    $projectName = $_POST['project_name'];
    // $createdAt = date('Y-m-d H:i:s');

    // Read file content
    $fileContent = file_get_contents($fileTmpName);
    $fileContent = mysqli_real_escape_string($mysqli, $fileContent);

    // Insert file into database
    $sql = "INSERT INTO files (name, mime, data, sender, project_name) VALUES ('$fileName', '$fileType', '$fileContent', '$senderName', '$projectName')";

    if ($mysqli->query($sql) === TRUE) {
        echo "<script>
                alert('File uploaded successfully.');
                window.location.href = 'dashboard.php';
            </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $mysqli->error;
    }

    $mysqli->close();
}
?>
