function confirm_logout()
{
return confirm("Are you sure you want to logout?");
}