<?php
include "koneksi.php";

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Fetch file
    $sql = "SELECT name, mime, data FROM files WHERE id = $id";
    $result = $mysqli->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Output file
        header("Content-type: " . $row['mime']);
        header('Content-Disposition: attachment; filename="' . $row['name'] . '"');
        echo $row['data'];
    } else {
        echo "File not found.";
    }
}

$mysqli->close();
?>
