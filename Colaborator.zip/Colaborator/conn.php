<?php
date_default_timezone_set("Asia/Jakarta");
$date=date('F j, Y g:i:a');

//mysqli procedural
$conn=mysqli_connect("localhost","root","","db_mapen");
if(!$conn){
	die("Connection failed: " . mysqli_connect_error());
}
?>